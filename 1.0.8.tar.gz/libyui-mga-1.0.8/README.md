libyui-mga
=============

libyui plugins/extensions for the Mageia tools
